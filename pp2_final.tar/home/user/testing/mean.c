#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include<sys/resource.h>
#include "lib.h"

int mean_test()
{
	int p; 
  if((p = getpriority(PRIO_PROCESS,0))<0){
    perror("getpriority()");
  }

  printf("Before Nice: %d\n",p);

  int c;
  if((c=nice(8))<0){
    perror("nice()");
  }

  if((p=getpriority(PRIO_PROCESS,0))<0){
    perror("getpriority()");
  }

  printf("After Nice, before Mean: %d\n",p);

  int b; 
  if((b=ander6_mean(4))<0){
    perror("ander6_mean()");
  }

  int q = getpriority(PRIO_PROCESS,0);

  printf("After Mean: %d\n",q);

  return 0;
}

int main() {mean_test();}