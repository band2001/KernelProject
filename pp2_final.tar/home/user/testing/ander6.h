#ifndef ANDER6_H
#define ANDER6_H

typedef struct ander6 {
  int pid;
  long __state;
  unsigned int flags;
  unsigned int ptrace;
  int on_rq;
  int prio;
  int static_prio;
  int normal_prio;
  unsigned int policy;
  int nr_cpus_allowed;
  int exit_state;
  int exit_code;
  int exit_signal;
  int pdeath_signal;
  unsigned int jobctl;
  unsigned int personality;
  unsigned long nvcsw;
  unsigned long nivcsw;
  unsigned long min_flt;
  unsigned long maj_flt;
  int total_link_count;
  unsigned long sas_ss_sp;
  unsigned long ptrace_message;
  int nr_dirtied;
  int nr_dirtied_pause;
  unsigned long dirty_paused_when;
  unsigned long timer_slack_ns;
  unsigned long default_timer_slack_ns;
}ander6_t;

#endif
