/* test program for lib.c */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include<sys/resource.h>
#include "lib.h"
#include<linux/sched.h>
#include"ander6.h"

int main()
{
  /*int rv;
  char *msg = "Hello, world!\n";
  printf("dub2(1,5) returns %d\n", rv = dub2(1, 5));

  printf("Test of write on fd %d:\n", rv);
  write(rv, msg, strlen(msg));*/

  int a = ander6_mycall();
  printf("ander6_mycall() returns %d\n", a);

  int p; 
  if((p = getpriority(PRIO_PROCESS,0))<0){
    perror("getpriority()");
  }

  printf("Before Mean: %d\n",p);

  /*int c;
  if((c=nice(8))<0){
    perror("nice()");
  }

  if((p=getpriority(PRIO_PROCESS,0))<0){
    perror("getpriority()");
  }

  printf("After Nice, before Mean: %d\n",p);*/

  int b; 
  if((b=ander6_mean(4))<0){
    perror("ander6_mean()");
  }

  int q = getpriority(PRIO_PROCESS,0);

  printf("After Mean: %d\n",q);

  printf("ander6_mean() returns %d, before: %d after: %d\n", b,p,q);

  ander6_t mystruct;

  ander6_task_struct(&mystruct);

  int pid = (&mystruct)->pid;

  printf("mystruct->pid = %d\n", pid);
  printf("getpid() = %d\n", getpid());

  return 0;
}
