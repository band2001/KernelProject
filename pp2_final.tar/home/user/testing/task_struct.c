#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include<sys/resource.h>
#include "lib.h"
#include "ander6.h"

int task_struct() {
	int pid_g;
	if((pid_g = getpid())<0){
		perror("getpid()");
		return -1;
	}

	ander6_t current_task;

	int ret;
	if((ret=ander6_task_struct(&current_task))<0){
		perror("ander6_task_struct()");
		return -1;
	}

	int pid_a = (&current_task)->pid;

	printf("pid from getpid(): %d  pid from ander6_task_struct(): %d\n",pid_g,pid_a);

	return 0;
}

int main() {
	task_struct();
}