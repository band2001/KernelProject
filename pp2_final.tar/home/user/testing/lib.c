/* library source for new system calls */

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>
#include<linux/sched.h>
#include<ander6.h>

extern int errno;

#define __NR_dub2		 33
#define __NR_ander6_mycall  449
#define __NR_ander6_mean  450
#define __NR_ander6_task_struct  451

/* NOTE:  for M1 ONLY, uncomment the following line */
/* #define __NR_dub2		 63 */

int dub2(int fd, int fd2) {
  return syscall(__NR_dub2, fd, fd2);
}

int ander6_mycall(){
  return syscall(__NR_ander6_mycall);
}

int ander6_mean(int increment){
  return syscall(__NR_ander6_mean, increment);
}

int ander6_task_struct(ander6_t *tsk){
  return syscall(__NR_ander6_task_struct, tsk);
}




