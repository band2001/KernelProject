/* Header file for example of system call library function.
   #include this file in your test program */

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>
#include<linux/sched.h>
#include<ander6.h>

int dub2(int fd, int fd2);
int ander6_mycall();
int ander6_mean(int increment);
int ander6_task_struct(ander6_t *tsk);
